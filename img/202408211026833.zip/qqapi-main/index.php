<?php
include("./includes/common.php");

exit("<script language='javascript'>window.location.href='./admin/';</script>");
